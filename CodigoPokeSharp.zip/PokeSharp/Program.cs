﻿using System;

namespace PokeSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Encounter pokemon = new Encounter("Sentret",140,140); 
        }
    }
}
